/*
 *  groebner.cc
 *  PolyBoRi
 *
 *  Created by Michael Brickenstein on 19.04.06.
 *  Copyright 2006 The PolyBoRi Team. See LICENSE file.
 *
 */

#include <polybori/groebner/groebner.h>
#include <polybori/groebner/groebner_alg.h>
