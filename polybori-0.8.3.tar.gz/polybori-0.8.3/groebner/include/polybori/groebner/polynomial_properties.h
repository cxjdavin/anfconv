//
//  untitled
//
//  Created by  on 2008-04-16.
//  Copyright (c) 2008 The PolyBoRi Team. See LICENSE file.
//  PolyBoRi Project
#include "groebner_defs.h"
BEGIN_NAMESPACE_PBORIGB

bool is_rewriteable(const Polynomial& p, const MonomialSet& leading_terms);

END_NAMESPACE_PBORIGB
