/*  Copyright (c) 2005-2007 by The PolyBoRi Team */

#ifndef DLEX4_DATA_H
#define DLEX4_DATA_H
#include "groebner_defs.h"
BEGIN_NAMESPACE_PBORIGB
extern const unsigned short dlex4var_data[][7];
END_NAMESPACE_PBORIGB
#endif
