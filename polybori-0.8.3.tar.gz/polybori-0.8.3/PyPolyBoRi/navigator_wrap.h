/*
 *  navigator_wrap.h
 *  PolyBoRi
 *
 *  Created by Michael Brickenstein on 06.04.06.
 *  Copyright 2006 The PolyBoRi Team. See LICENSE file.
 *
 */

void export_nav();
