/*
 *  pairs.h
 *  PolyBoRi
 *
 *  Created by Michael Brickenstein on 12.04.06.
 *  Copyright 2006 The PolyBoRi Team. See LICENSE file.
 *
 */

void export_pairs();
