/*
 *  slimgb.h
 *  PolyBoRi
 *
 *  Created by Michael Brickenstein on 02.05.06.
 *  Copyright 2006 The PolyBoRi Team. See LICENSE file.
 *
 */
#ifndef VARIABLE_BLOCK_H
#define VARIABLE_BLOCK_H

void export_variable_block();
#endif
